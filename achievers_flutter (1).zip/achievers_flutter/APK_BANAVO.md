# APK કેવી રીતે મેળવવો — કંઈ install કર્યા વગર

તમારા કમ્પ્યુટરમાં Flutter કે Android Studio ઉતારવાની જરૂર નથી.
GitHub મફતમાં cloud માં APK બનાવી આપશે. કુલ સમય: પહેલી વાર ~20 મિનિટ,
પછી દર વખતે ~8 મિનિટ.

---

## પગલું 1 — GitHub account

github.com પર જાઓ → **Sign up** → email અને password થી account બનાવો.
(પહેલેથી હોય તો સીધા પગલું 2 પર.)

## પગલું 2 — નવું repository બનાવો

1. ઉપર જમણે **+** → **New repository**
2. Repository name: `achievers`
3. **Private** પસંદ કરો (તમારો કોડ ખાનગી રહેશે — Actions તો પણ મફત ચાલશે)
4. **Create repository** દબાવો

## પગલું 3 — ફાઇલો ચઢાવો

નવા repository ના પાના પર **uploading an existing file** લિંક દેખાશે
(અથવા **Add file → Upload files**).

1. `achievers_flutter.zip` ને કમ્પ્યુટર પર extract કરો
2. અંદરના `achievers_flutter` ફોલ્ડરની **બધી ફાઇલો અને ફોલ્ડરો** માઉસથી
   ખેંચીને upload વાળા ખાનામાં છોડો
3. નીચે **Commit changes** દબાવો

> **ધ્યાન:** `.github` નામનું ફોલ્ડર પણ ચઢવું જ જોઈએ — એમાં જ build ની
> સૂચના છે. કેટલાક કમ્પ્યુટરમાં ડોટથી શરૂ થતાં ફોલ્ડર છુપાયેલાં હોય છે.
> Windows માં: File Explorer → View → **Hidden items** ટિક કરો.
> Mac માં: Finder માં **Cmd + Shift + .** દબાવો.

## પગલું 4 — Build જુઓ

Upload થતાં જ build આપોઆપ શરૂ થઈ જશે.

1. ઉપર **Actions** tab દબાવો
2. "Build APK" નામનું કામ ચાલતું દેખાશે (પીળું ટપકું 🟡)
3. 8-10 મિનિટ રાહ જુઓ

## પગલું 5 — APK ઉતારો

લીલી ટિક ✅ દેખાય એટલે:

1. એ build પર ક્લિક કરો
2. પાનાની નીચે **Artifacts** ખાનામાં **achievers-apk** દેખાશે
3. એના પર ક્લિક કરો — zip ઉતરશે
4. Extract કરો → અંદર `app-release.apk` છે

એ ફાઇલ ફોનમાં મોકલો (WhatsApp / USB / Google Drive), ફોનમાં
**Settings → Install unknown apps** ચાલુ કરીને ફાઇલ પર ટેપ કરો.

---

## લાલ ✗ આવે તો

એનો અર્થ કોડમાં ભૂલ છે — ગભરાવાની જરૂર નથી, પહેલી વાર સામાન્ય છે.

1. લાલ ✗ વાળા build પર ક્લિક કરો
2. `build` પર ક્લિક કરો
3. જે પગલું લાલ છે એ ખોલો
4. છેલ્લી 20-30 લીટી copy કરીને મને મોકલો

હું સુધારેલી ફાઇલ આપીશ, તમે એ એક ફાઇલ GitHub પર બદલશો, build ફરી
આપોઆપ ચાલશે.

---

## પછી કંઈ બદલવું હોય તો

GitHub પર ફાઇલ ખોલો → પેન્સિલ ✏️ દબાવો → સુધારો → Commit.
નવો APK આપોઆપ બની જશે. કમ્પ્યુટર પર કંઈ કરવાનું નહીં.

---

## બે વાત જાણી લેવા જેવી

**આ APK ફોનમાં install થશે, પણ Play Store માટે નહીં ચાલે.**
એ debug key થી signed છે. Play Store પર મૂકવું હોય તો ખરી signing key
બનાવવી પડે — એ અલગ કામ છે, જરૂર પડે ત્યારે કરીશું.

**GitHub Actions ની મફત મર્યાદા:** private repository માટે મહિને 2,000
મિનિટ. એક build ~10 મિનિટ લે છે, એટલે મહિને 200 build. તમારે એટલા નહીં
જોઈએ. Public repository માટે તો સાવ અમર્યાદિત છે.
