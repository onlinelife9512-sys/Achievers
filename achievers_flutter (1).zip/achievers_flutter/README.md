# Achievers — Flutter Android app

A native Flutter port of the web app at vijaysirpatel.netlify.app.
**No WebView** — every screen is rebuilt with real Flutter widgets.

---

## Build it (first time)

Run these in order, inside this folder:

```bash
# 1. Generate the Android project files (gradle, wrapper, MainActivity).
#    This does NOT touch lib/ or pubspec.yaml.
flutter create --platforms=android .

# 2. Pull the packages
flutter pub get

# 3. App icon + splash screen
dart run flutter_launcher_icons
dart run flutter_native_splash:create

# 4. Run it on a connected phone (fastest way to see errors)
flutter run

# 5. When it works, build the installable APK
flutter build apk --release
```

The APK lands at:
`build/app/outputs/flutter-apk/app-release.apk`

Copy that to a phone and tap it to install (enable "Install unknown apps" first).

**Step 1 is required.** This zip ships `lib/`, `pubspec.yaml`, `assets/` and a
custom `AndroidManifest.xml`, but not the gradle wrapper (a binary file).
`flutter create` fills in everything missing and keeps the manifest.

### Opening in Android Studio

File → Open → select this folder. Let it finish indexing, then use the
run button. If Android Studio doesn't see a device, check
Tools → Device Manager.

---

## What each file does

```
lib/
  main.dart                      entry point, loads storage then shows splash
  theme.dart                     colours + fonts copied from the web app's :root
  data/seed_questions.dart       the 100 sample MCQs, ported from the JS
  models/question.dart           one MCQ
  models/paper.dart              one generated paper
  services/store.dart            saves the bank + history to the device
  services/pdf_service.dart      builds the PDF (replaces jsPDF)
  services/import_service.dart   Excel/CSV import, export, JSON backup
  widgets/common.dart            Panel, GoldButton, Chip2, etc.
  screens/splash_screen.dart     "Tap anywhere to begin" + rotating rays
  screens/menu_screen.dart       "What are we working on?"
  screens/paper_gen_screen.dart  the generator form
  screens/paper_preview_screen.dart  preview + Download / Share / Print
  screens/question_bank_screen.dart  subject grid → question list
  screens/history_screen.dart    "Previously Generated"
  screens/settings_screen.dart   import / export / backup (new)
```

---

## Differences from the web version

Four things in the web app were broken or missing. They are fixed here — if you
want the old behaviour back, the notes below say where to look.

**1. Difficulty now actually filters.**
In the web app `generatePaper()` read the Easy/Medium/Hard chip but never used
it to filter — it only got printed in the subtitle. Questions had no difficulty
field at all. Here `Question.difficulty` is real and the filter works. The 100
bundled questions are all marked `Medium`, so picking Easy or Hard shows
*0 available* until you import questions that carry their own difficulty.
A live counter above the Generate button shows the count as you change filters,
so you see this immediately instead of after pressing the button.

**2. Class 11 / 12 now filters too.**
Same story — `cls` only went into the title. Questions imported with a
`standard` column are filtered properly. The bundled ones have no class set, so
they show under both (rather than disappearing).

**3. History survives restarts.**
`paperHistory` was a plain array, so "Previously Generated" emptied every time
the page reloaded. It's now written to device storage.

**4. Excel import and backup added.**
Neither existed in the web app. Settings → Import Excel/CSV accepts these
columns (header names are matched loosely — `chapterName`, `Option A`, `Answer`
and similar all work):

```
subject | standard | chapter | topic | difficulty | question
optionA | optionB | optionC | optionD | answer | explanation
```

`answer` can be a letter (B), a number (2), or the answer text itself.
Settings → Template hands you a filled-in sample CSV.

**Also changed:** the PDF now uses Noto instead of Helvetica, so Gujarati text
prints correctly — jsPDF could not render it at all. Page numbers, a footer and
an optional answer key were added.

---

## Notes

- **Everything is stored on the phone.** There is no server and no sync between
  devices. Settings → Save backup writes a JSON file you can move across phones.
- **Fonts and PDF fonts download on first use** (google_fonts and the PDF's
  Noto Gujarati). Run the app once with internet; after that it works offline.
  To make it fully offline from the start, download the Fraunces, Inter and
  Noto Sans Gujarati `.ttf` files into `assets/fonts/`, declare them under
  `flutter:` → `fonts:` in `pubspec.yaml`, and swap the `GoogleFonts.*` calls in
  `lib/theme.dart` for plain `TextStyle(fontFamily: ...)`.
- **This project has not been compiled or run.** It was written without a
  Flutter toolchain available, so expect a small fix or two on the first
  `flutter run` — a package version bump is the most likely one. Send the error
  text and it can be sorted quickly.
