import 'dart:convert';
import 'dart:io';
import 'package:csv/csv.dart';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../models/question.dart';
import 'store.dart';

/// Excel / CSV import + JSON backup. Neither existed in the web app; both are
/// added here so a teacher can load a real question bank instead of the
/// 100 bundled samples.
class ImportService {
  /// Column names accepted in the header row (case- and space-insensitive).
  static const _canonical = [
    'subject',
    'standard',
    'chapter',
    'topic',
    'difficulty',
    'question',
    'optiona',
    'optionb',
    'optionc',
    'optiond',
    'answer',
    'explanation',
  ];

  static const exportHeader = [
    'subject',
    'standard',
    'chapter',
    'topic',
    'difficulty',
    'question',
    'optionA',
    'optionB',
    'optionC',
    'optionD',
    'answer',
    'explanation',
  ];

  static String _n(String s) =>
      s.toLowerCase().replaceAll(RegExp(r'[\s_]'), '').trim();

  /// Maps the many header spellings teachers actually use onto our fields.
  static String? _field(String header) {
    final h = _n(header);
    const alias = {
      'chaptername': 'chapter',
      'class': 'standard',
      'std': 'standard',
      'questiontext': 'question',
      'text': 'question',
      'correctanswer': 'answer',
      'correct': 'answer',
      'ans': 'answer',
      'a': 'optiona',
      'b': 'optionb',
      'c': 'optionc',
      'd': 'optiond',
      'level': 'difficulty',
    };
    if (_canonical.contains(h)) return h;
    return alias[h];
  }

  /// "B" / "2" / "Option B" → 1
  static int _answerIndex(String raw, List<String> options) {
    final v = raw.trim();
    if (v.isEmpty) return 0;
    final letter = v.toUpperCase().replaceAll(RegExp(r'[^A-D]'), '');
    if (letter.isNotEmpty) return 'ABCD'.indexOf(letter[0]).clamp(0, 3);
    final n = int.tryParse(v);
    if (n != null) return (n >= 1 && n <= 4) ? n - 1 : n.clamp(0, 3);
    // Fall back to matching the answer text against the options.
    final i = options.indexWhere((o) => o.trim() == v);
    return i < 0 ? 0 : i;
  }

  static String _difficulty(String raw) {
    final v = raw.trim().toLowerCase();
    if (v.startsWith('e') || v.startsWith('l')) return 'Easy';
    if (v.startsWith('h') || v.startsWith('a')) return 'Hard';
    return 'Medium';
  }

  static String _standard(String raw) {
    final v = raw.trim();
    if (v.contains('11')) return '11th';
    if (v.contains('12')) return '12th';
    return '';
  }

  static Question? _rowToQuestion(Map<String, String> r, int i) {
    final text = (r['question'] ?? '').trim();
    if (text.isEmpty) return null;
    final options = [
      (r['optiona'] ?? '').trim(),
      (r['optionb'] ?? '').trim(),
      (r['optionc'] ?? '').trim(),
      (r['optiond'] ?? '').trim(),
    ];
    if (options.every((o) => o.isEmpty)) return null;
    return Question(
      id: 'imp_${DateTime.now().microsecondsSinceEpoch}_$i',
      subject: (r['subject'] ?? '').trim().isEmpty
          ? 'Biology'
          : r['subject']!.trim(),
      chapter: (r['chapter'] ?? '').trim(),
      topic: (r['topic'] ?? '').trim(),
      text: text,
      options: options,
      answer: _answerIndex(r['answer'] ?? '', options),
      difficulty: _difficulty(r['difficulty'] ?? ''),
      standard: _standard(r['standard'] ?? ''),
      explanation: (r['explanation'] ?? '').trim(),
    );
  }

  /// Lets the user pick a .xlsx/.xls/.csv file and returns the parsed rows.
  /// Returns null when the picker was dismissed.
  static Future<List<Question>?> pickAndParse() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx', 'xls', 'csv'],
      withData: true,
    );
    if (res == null || res.files.isEmpty) return null;
    final f = res.files.first;
    final bytes = f.bytes ??
        (f.path != null ? await File(f.path!).readAsBytes() : null);
    if (bytes == null) return <Question>[];

    final rows = f.extension?.toLowerCase() == 'csv'
        ? _parseCsv(utf8.decode(bytes, allowMalformed: true))
        : _parseXlsx(bytes);

    final out = <Question>[];
    for (var i = 0; i < rows.length; i++) {
      final q = _rowToQuestion(rows[i], i);
      if (q != null) out.add(q);
    }
    return out;
  }

  static List<Map<String, String>> _parseCsv(String text) {
    final table = const CsvToListConverter(eol: '\n', shouldParseNumbers: false)
        .convert(text.replaceAll('\r\n', '\n').replaceAll('\r', '\n'));
    if (table.isEmpty) return [];
    return _mapRows(
      table.first.map((e) => '$e').toList(),
      table.skip(1).map((r) => r.map((e) => '$e').toList()).toList(),
    );
  }

  static List<Map<String, String>> _parseXlsx(List<int> bytes) {
    final book = Excel.decodeBytes(bytes);
    if (book.tables.isEmpty) return [];
    final sheet = book.tables[book.tables.keys.first]!;
    if (sheet.rows.isEmpty) return [];
    String cell(Data? d) => d?.value?.toString().trim() ?? '';
    return _mapRows(
      sheet.rows.first.map(cell).toList(),
      sheet.rows.skip(1).map((r) => r.map(cell).toList()).toList(),
    );
  }

  static List<Map<String, String>> _mapRows(
      List<String> header, List<List<String>> body) {
    final cols = header.map(_field).toList();
    final out = <Map<String, String>>[];
    for (final row in body) {
      if (row.every((c) => c.trim().isEmpty)) continue;
      final m = <String, String>{};
      for (var i = 0; i < cols.length && i < row.length; i++) {
        final key = cols[i];
        if (key != null) m[key] = row[i];
      }
      if (m.isNotEmpty) out.add(m);
    }
    return out;
  }

  // ───────────── export ─────────────

  static Future<void> exportExcel() async {
    final qs = Store.instance.questions;
    final book = Excel.createExcel();
    final sheet = book[book.getDefaultSheet()!];
    sheet.appendRow(exportHeader.map((h) => TextCellValue(h)).toList());
    for (final q in qs) {
      sheet.appendRow([
        TextCellValue(q.subject),
        TextCellValue(q.standard),
        TextCellValue(q.chapter),
        TextCellValue(q.topic),
        TextCellValue(q.difficulty),
        TextCellValue(q.text),
        TextCellValue(q.options[0]),
        TextCellValue(q.options[1]),
        TextCellValue(q.options[2]),
        TextCellValue(q.options[3]),
        TextCellValue(q.answerLetter),
        TextCellValue(q.explanation),
      ]);
    }
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/achievers_questions.xlsx');
    await file.writeAsBytes(book.encode()!);
    await Share.shareXFiles([XFile(file.path)],
        text: 'Achievers question bank');
  }

  /// A blank .csv the teacher can fill in — same columns the importer expects.
  static Future<void> exportTemplate() async {
    const sample = [
      'Biology',
      '11th',
      'The Living World',
      'Taxonomy',
      'Easy',
      'Which scientist is called the Father of Taxonomy?',
      'Aristotle',
      'Carolus Linnaeus',
      'Robert Hooke',
      'Charles Darwin',
      'B',
      'Linnaeus is known as the Father of Taxonomy.',
    ];
    final csv = const ListToCsvConverter()
        .convert([exportHeader, sample]);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/achievers_template.csv');
    await file.writeAsString('\uFEFF$csv');
    await Share.shareXFiles([XFile(file.path)],
        text: 'Achievers import template');
  }

  // ───────────── backup ─────────────

  static Future<void> backupOut() async {
    final data = {
      'v': 1,
      'at': DateTime.now().toIso8601String(),
      'questions': Store.instance.questions.map((q) => q.toJson()).toList(),
      'history': Store.instance.history.map((p) => p.toJson()).toList(),
    };
    final dir = await getTemporaryDirectory();
    final stamp = DateTime.now().toIso8601String().split('T').first;
    final file = File('${dir.path}/achievers_backup_$stamp.json');
    await file.writeAsString(jsonEncode(data));
    await Share.shareXFiles([XFile(file.path)], text: 'Achievers backup');
  }

  /// Returns the number of questions restored, or null if cancelled.
  static Future<int?> backupIn() async {
    final res = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['json'],
      withData: true,
    );
    if (res == null || res.files.isEmpty) return null;
    final f = res.files.first;
    final bytes = f.bytes ??
        (f.path != null ? await File(f.path!).readAsBytes() : null);
    if (bytes == null) return null;

    final map = jsonDecode(utf8.decode(bytes)) as Map<String, dynamic>;
    final qs = ((map['questions'] as List?) ?? const [])
        .map((e) => Question.fromJson(Map<String, dynamic>.from(e)))
        .toList();
    await Store.instance.replaceAll(qs);
    return qs.length;
  }
}
