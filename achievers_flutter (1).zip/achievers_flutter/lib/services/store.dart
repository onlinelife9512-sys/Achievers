import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../data/seed_questions.dart';
import '../models/paper.dart';
import '../models/question.dart';

/// Single source of truth for the question bank and paper history.
///
/// The web app kept history in a plain array, so it disappeared on refresh.
/// Here everything is written to device storage and survives restarts.
class Store extends ChangeNotifier {
  static final Store instance = Store._();
  Store._();

  static const _kQuestions = 'achievers_questions_v1';
  static const _kHistory = 'achievers_history_v1';
  static const _kSeeded = 'achievers_seeded_v1';

  final List<Question> questions = [];
  final List<Paper> history = [];
  bool ready = false;

  Future<void> init() async {
    final p = await SharedPreferences.getInstance();

    final raw = p.getString(_kQuestions);
    if (raw != null) {
      questions
        ..clear()
        ..addAll((jsonDecode(raw) as List)
            .map((e) => Question.fromJson(Map<String, dynamic>.from(e))));
    } else if (!(p.getBool(_kSeeded) ?? false)) {
      // First launch — load the 100 questions bundled with the app.
      questions
        ..clear()
        ..addAll(kSeedQuestions);
      await p.setBool(_kSeeded, true);
      await _saveQuestions(p);
    }

    final h = p.getString(_kHistory);
    if (h != null) {
      history
        ..clear()
        ..addAll((jsonDecode(h) as List)
            .map((e) => Paper.fromJson(Map<String, dynamic>.from(e))));
    }

    ready = true;
    notifyListeners();
  }

  Future<void> _saveQuestions([SharedPreferences? pref]) async {
    final p = pref ?? await SharedPreferences.getInstance();
    await p.setString(
        _kQuestions, jsonEncode(questions.map((q) => q.toJson()).toList()));
  }

  Future<void> _saveHistory() async {
    final p = await SharedPreferences.getInstance();
    await p.setString(
        _kHistory, jsonEncode(history.map((e) => e.toJson()).toList()));
  }

  // ───────────── questions ─────────────

  /// Adds questions, skipping ones whose text already exists.
  /// Returns (added, skipped).
  Future<(int, int)> addQuestions(List<Question> incoming) async {
    final seen = questions.map((q) => _norm(q.text)).toSet();
    var added = 0, skipped = 0;
    for (final q in incoming) {
      final k = _norm(q.text);
      if (k.isEmpty || seen.contains(k)) {
        skipped++;
        continue;
      }
      seen.add(k);
      questions.add(q);
      added++;
    }
    if (added > 0) {
      await _saveQuestions();
      notifyListeners();
    }
    return (added, skipped);
  }

  Future<void> deleteQuestion(String id) async {
    questions.removeWhere((q) => q.id == id);
    await _saveQuestions();
    notifyListeners();
  }

  Future<void> replaceAll(List<Question> qs) async {
    questions
      ..clear()
      ..addAll(qs);
    await _saveQuestions();
    notifyListeners();
  }

  Future<void> clearQuestions() async {
    questions.clear();
    await _saveQuestions();
    notifyListeners();
  }

  // ───────────── history ─────────────

  Future<void> addPaper(Paper p) async {
    history.insert(0, p);
    if (history.length > 60) history.removeRange(60, history.length);
    await _saveHistory();
    notifyListeners();
  }

  Future<void> deletePaper(String id) async {
    history.removeWhere((p) => p.id == id);
    await _saveHistory();
    notifyListeners();
  }

  Future<void> clearHistory() async {
    history.clear();
    await _saveHistory();
    notifyListeners();
  }

  // ───────────── derived lookups ─────────────

  List<String> get subjects {
    final s = questions.map((q) => q.subject).toSet().toList()..sort();
    return s.isEmpty ? const ['Biology', 'Chemistry', 'Physics', 'Maths'] : s;
  }

  /// { chapter: [topic, topic, ...] } — mirrors getChaptersForSubject().
  Map<String, List<String>> chapterMap(String subject) {
    final map = <String, List<String>>{};
    for (final q in questions.where((q) => q.subject == subject)) {
      final list = map.putIfAbsent(q.chapter, () => []);
      if (q.topic.isNotEmpty && !list.contains(q.topic)) list.add(q.topic);
    }
    for (final v in map.values) {
      v.sort();
    }
    return map;
  }

  /// Filter used by both the generator and the live availability counter.
  List<Question> pool({
    required String subject,
    String? standard,
    String? chapter,
    String? difficulty,
    Set<String> topics = const {},
  }) {
    return questions.where((q) {
      if (q.subject != subject) return false;
      if (chapter != null && chapter.isNotEmpty && q.chapter != chapter) {
        return false;
      }
      // Unclassified questions (the seeded ones) match any class.
      if (standard != null &&
          standard.isNotEmpty &&
          q.standard.isNotEmpty &&
          q.standard != standard) {
        return false;
      }
      if (difficulty != null &&
          difficulty.isNotEmpty &&
          difficulty != 'All' &&
          q.difficulty != difficulty) {
        return false;
      }
      if (topics.isNotEmpty && !topics.contains(q.topic)) return false;
      return true;
    }).toList();
  }

  static String _norm(String s) =>
      s.toLowerCase().replaceAll(RegExp(r'[^a-z0-9\u0A80-\u0AFF]'), '');
}
