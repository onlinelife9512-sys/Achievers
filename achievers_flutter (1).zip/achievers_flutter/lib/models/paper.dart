import 'question.dart';

/// A generated question paper. Unlike the web app (where history lived in a
/// plain array and vanished on refresh), these are persisted to device storage.
class Paper {
  final String id;
  final String title;
  final String subject;
  final String standard;
  final String chapter;
  final String difficulty;
  final String time;
  final int marks;
  final DateTime createdAt;
  final List<Question> questions;

  const Paper({
    required this.id,
    required this.title,
    required this.subject,
    required this.standard,
    required this.chapter,
    required this.difficulty,
    required this.time,
    required this.marks,
    required this.createdAt,
    required this.questions,
  });

  /// Matches the original app's subtitle: "Medium · 10 Questions".
  String get meta => '$difficulty · ${questions.length} Questions';

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'subject': subject,
        'standard': standard,
        'chapter': chapter,
        'difficulty': difficulty,
        'time': time,
        'marks': marks,
        'createdAt': createdAt.toIso8601String(),
        'questions': questions.map((q) => q.toJson()).toList(),
      };

  factory Paper.fromJson(Map<String, dynamic> j) => Paper(
        id: '${j['id'] ?? ''}',
        title: '${j['title'] ?? ''}',
        subject: '${j['subject'] ?? ''}',
        standard: '${j['standard'] ?? ''}',
        chapter: '${j['chapter'] ?? ''}',
        difficulty: '${j['difficulty'] ?? ''}',
        time: '${j['time'] ?? ''}',
        marks: (j['marks'] is int) ? j['marks'] as int : 0,
        createdAt:
            DateTime.tryParse('${j['createdAt']}') ?? DateTime.now(),
        questions: ((j['questions'] as List?) ?? const [])
            .map((e) => Question.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}
