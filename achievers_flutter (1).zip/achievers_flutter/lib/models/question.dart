/// A single multiple-choice question.
///
/// The original web app stored only {chapter, topic, text, options, answer}.
/// `difficulty` and `standard` are added here so the Easy/Medium/Hard and
/// Class 11/12 selectors actually filter instead of being decorative, and so
/// imported Excel rows keep their own values.
class Question {
  final String id;
  final String subject;
  final String chapter;
  final String topic;
  final String text;
  final List<String> options; // always 4: A, B, C, D
  final int answer; // 0-based index into options
  final String difficulty; // Easy | Medium | Hard
  final String standard; // "11th" | "12th" | "" when unclassified
  final String explanation;
  final bool seeded;

  const Question({
    required this.id,
    required this.subject,
    required this.chapter,
    required this.topic,
    required this.text,
    required this.options,
    required this.answer,
    this.difficulty = 'Medium',
    this.standard = '',
    this.explanation = '',
    this.seeded = false,
  });

  String get answerLetter =>
      (answer >= 0 && answer < 4) ? const ['A', 'B', 'C', 'D'][answer] : 'A';

  Map<String, dynamic> toJson() => {
        'id': id,
        'subject': subject,
        'chapter': chapter,
        'topic': topic,
        'text': text,
        'options': options,
        'answer': answer,
        'difficulty': difficulty,
        'standard': standard,
        'explanation': explanation,
        'seeded': seeded,
      };

  factory Question.fromJson(Map<String, dynamic> j) {
    final opts = (j['options'] as List?)?.map((e) => '$e').toList() ?? const [];
    return Question(
      id: '${j['id'] ?? DateTime.now().microsecondsSinceEpoch}',
      subject: '${j['subject'] ?? ''}',
      chapter: '${j['chapter'] ?? ''}',
      topic: '${j['topic'] ?? ''}',
      text: '${j['text'] ?? ''}',
      options: [
        ...opts,
        ...List.filled((4 - opts.length).clamp(0, 4), ''),
      ].take(4).toList(),
      answer: (j['answer'] is int) ? j['answer'] as int : 0,
      difficulty: '${j['difficulty'] ?? 'Medium'}',
      standard: '${j['standard'] ?? ''}',
      explanation: '${j['explanation'] ?? ''}',
      seeded: j['seeded'] == true,
    );
  }
}
