import 'package:flutter/material.dart';
import '../services/store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'history_screen.dart';
import 'paper_gen_screen.dart';
import 'question_bank_screen.dart';
import 'settings_screen.dart';

/// "What are we working on?" — the web app's menu, plus a Settings entry for
/// the import/backup tools that the web version did not have.
class MenuScreen extends StatelessWidget {
  const MenuScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: A.bg,
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Store.instance,
          builder: (context, _) {
            final s = Store.instance;
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 32),
              children: [
                Row(
                  children: [
                    Text('Achievers',
                        style: A.display(19, w: FontWeight.w600, c: A.gold)),
                    const Spacer(),
                    IconButton(
                      onPressed: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => const SettingsScreen())),
                      icon: const Icon(Icons.settings_outlined,
                          color: A.muted, size: 22),
                      tooltip: 'Settings',
                    ),
                  ],
                ),
                const SizedBox(height: 26),
                Text('What are we',
                    style: A.display(34, w: FontWeight.w300, h: 1.15)),
                Text('working on?',
                    style: A.display(34, w: FontWeight.w600, h: 1.15, c: A.gold)),
                const SizedBox(height: 8),
                Text('${s.questions.length} questions in your bank',
                    style: A.body(13, c: A.muted)),
                const SizedBox(height: 26),
                _Card(
                  emoji: '📝',
                  gradient: A.goldGrad,
                  title: 'Paper Generation',
                  subtitle: 'Build a custom question paper in seconds',
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const PaperGenScreen())),
                ),
                _Card(
                  emoji: '📚',
                  gradient: A.tealGrad,
                  title: 'Question Bank',
                  subtitle: 'Browse questions by subject & topic',
                  onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => const QuestionBankScreen())),
                ),
                _Card(
                  emoji: '🗂️',
                  gradient: A.violetGrad,
                  title: 'Previously Generated',
                  subtitle: s.history.isEmpty
                      ? "Revisit papers you've already created"
                      : '${s.history.length} saved paper${s.history.length == 1 ? '' : 's'}',
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const HistoryScreen())),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Card extends StatelessWidget {
  final String emoji, title, subtitle;
  final Gradient gradient;
  final VoidCallback onTap;

  const _Card({
    required this.emoji,
    required this.title,
    required this.subtitle,
    required this.gradient,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Panel(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(18),
      onTap: onTap,
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(
              gradient: gradient,
              borderRadius: BorderRadius.circular(16),
            ),
            alignment: Alignment.center,
            child: Text(emoji, style: const TextStyle(fontSize: 24)),
          ),
          const SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: A.display(17, w: FontWeight.w600)),
                const SizedBox(height: 3),
                Text(subtitle, style: A.body(12.5, c: A.muted, h: 1.4)),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded, color: A.muted),
        ],
      ),
    );
  }
}
