import 'package:flutter/material.dart';
import '../services/import_service.dart';
import '../services/store.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Import / export / backup. None of this existed in the web app — it is what
/// lets a teacher replace the 100 bundled samples with a real question bank.
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _busy = false;

  Future<void> _guard(Future<void> Function() job) async {
    setState(() => _busy = true);
    try {
      await job();
    } catch (e) {
      if (mounted) {
        toast(context, 'That did not work. Please check the file and retry.',
            bad: true);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _import() => _guard(() async {
        final parsed = await ImportService.pickAndParse();
        if (parsed == null) return; // cancelled
        if (parsed.isEmpty) {
          if (mounted) {
            toast(context, 'No usable rows found — check the column headers.',
                bad: true);
          }
          return;
        }
        final (added, skipped) = await Store.instance.addQuestions(parsed);
        if (!mounted) return;
        toast(context,
            'Imported $added question${added == 1 ? '' : 's'}${skipped > 0 ? '  ·  $skipped skipped' : ''}');
      });

  Future<void> _restore() => _guard(() async {
        final n = await ImportService.backupIn();
        if (n == null) return;
        if (mounted) toast(context, 'Restored $n questions');
      });

  Future<void> _confirmClear() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: A.panelHi,
        title: Text('Delete every question?',
            style: A.display(17, w: FontWeight.w600)),
        content: Text(
            'All ${Store.instance.questions.length} questions will be removed from this device. Export a backup first if you might need them.',
            style: A.body(13.5, c: A.muted, h: 1.5)),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: Text('Cancel', style: A.body(14, c: A.muted))),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              child: Text('Delete all',
                  style: A.body(14,
                      c: const Color(0xFFFCA5A5), w: FontWeight.w600))),
        ],
      ),
    );
    if (ok == true) {
      await Store.instance.clearQuestions();
      if (mounted) toast(context, 'Question bank cleared');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: A.bg,
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Store.instance,
          builder: (context, _) {
            final s = Store.instance;
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 36),
              children: [
                BackChip(onTap: () => Navigator.pop(context)),
                const SizedBox(height: 18),
                const SectionTitle('Settings',
                    subtitle: 'Your question bank and backups'),
                const SizedBox(height: 22),

                Panel(
                  child: Row(
                    children: [
                      _Stat('${s.questions.length}', 'Questions'),
                      _Stat('${s.subjects.length}', 'Subjects'),
                      _Stat('${s.history.length}', 'Papers'),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Question bank',
                          style: A.display(17, w: FontWeight.w600)),
                      const SizedBox(height: 5),
                      Text(
                          'Import an .xlsx or .csv file. Columns: subject, standard, chapter, topic, difficulty, question, optionA–D, answer, explanation.',
                          style: A.body(12.5, c: A.muted, h: 1.55)),
                      const SizedBox(height: 14),
                      GoldButton(
                        label: 'Import Excel / CSV',
                        icon: Icons.upload_file_rounded,
                        loading: _busy,
                        onPressed: _busy ? null : _import,
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: GhostButton(
                              label: 'Export Excel',
                              icon: Icons.table_chart_rounded,
                              onPressed: _busy || s.questions.isEmpty
                                  ? null
                                  : () => _guard(ImportService.exportExcel),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: GhostButton(
                              label: 'Template',
                              icon: Icons.description_outlined,
                              onPressed: _busy
                                  ? null
                                  : () => _guard(ImportService.exportTemplate),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Backup',
                          style: A.display(17, w: FontWeight.w600)),
                      const SizedBox(height: 5),
                      Text(
                          'Everything is stored on this phone only. Save a backup before clearing app data or switching devices.',
                          style: A.body(12.5, c: A.muted, h: 1.55)),
                      const SizedBox(height: 14),
                      Row(
                        children: [
                          Expanded(
                            child: GhostButton(
                              label: 'Save backup',
                              icon: Icons.save_alt_rounded,
                              onPressed: _busy
                                  ? null
                                  : () => _guard(ImportService.backupOut),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: GhostButton(
                              label: 'Restore',
                              icon: Icons.restore_rounded,
                              onPressed: _busy ? null : _restore,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Danger zone',
                          style: A.display(17, w: FontWeight.w600)),
                      const SizedBox(height: 12),
                      GhostButton(
                        label: 'Delete all questions',
                        icon: Icons.delete_outline_rounded,
                        color: const Color(0xFFFCA5A5),
                        onPressed: s.questions.isEmpty ? null : _confirmClear,
                      ),
                    ],
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String v, k;
  const _Stat(this.v, this.k);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        children: [
          Text(v, style: A.display(24, w: FontWeight.w600, c: A.gold)),
          const SizedBox(height: 2),
          Text(k, style: A.body(11, c: A.muted)),
        ],
      ),
    );
  }
}
