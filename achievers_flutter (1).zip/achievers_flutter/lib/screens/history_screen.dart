import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../services/store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'paper_preview_screen.dart';

/// "Previously Generated". In the web app this list lived in a plain array and
/// was lost on every refresh — here it is persisted to device storage.
class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: A.bg,
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Store.instance,
          builder: (context, _) {
            final papers = Store.instance.history;
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
              children: [
                Row(
                  children: [
                    BackChip(onTap: () => Navigator.pop(context)),
                    const Spacer(),
                    if (papers.isNotEmpty)
                      TextButton(
                        onPressed: () async {
                          final ok = await showDialog<bool>(
                            context: context,
                            builder: (_) => AlertDialog(
                              backgroundColor: A.panelHi,
                              title: Text('Clear all papers?',
                                  style: A.display(17, w: FontWeight.w600)),
                              content: Text(
                                  'All ${papers.length} saved papers will be removed. This cannot be undone.',
                                  style: A.body(13.5, c: A.muted)),
                              actions: [
                                TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, false),
                                    child: Text('Cancel',
                                        style: A.body(14, c: A.muted))),
                                TextButton(
                                    onPressed: () =>
                                        Navigator.pop(context, true),
                                    child: Text('Clear',
                                        style: A.body(14,
                                            c: const Color(0xFFFCA5A5),
                                            w: FontWeight.w600))),
                              ],
                            ),
                          );
                          if (ok == true) await Store.instance.clearHistory();
                        },
                        child: Text('Clear all',
                            style: A.body(13, c: A.muted)),
                      ),
                  ],
                ),
                const SizedBox(height: 18),
                const SectionTitle('Previously Generated',
                    subtitle: "Papers you've created"),
                const SizedBox(height: 22),
                if (papers.isEmpty)
                  const EmptyState(
                    emoji: '🗂️',
                    message:
                        'No papers generated yet.\nHead to Paper Generation to create your first one.',
                  )
                else
                  ...papers.map((p) => Panel(
                        margin: const EdgeInsets.only(bottom: 12),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => PaperPreviewScreen(paper: p)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Achievers',
                                style: A.body(10.5,
                                    w: FontWeight.w700, c: A.gold, ls: 1.2)),
                            const SizedBox(height: 8),
                            Text(p.title,
                                style: A.display(16.5,
                                    w: FontWeight.w600, h: 1.35)),
                            const SizedBox(height: 6),
                            Row(
                              children: [
                                Text(p.meta, style: A.body(12, c: A.muted)),
                                const Spacer(),
                                Text(
                                    DateFormat('dd MMM')
                                        .format(p.createdAt),
                                    style: A.body(11.5, c: A.muted)),
                              ],
                            ),
                          ],
                        ),
                      )),
              ],
            );
          },
        ),
      ),
    );
  }
}
