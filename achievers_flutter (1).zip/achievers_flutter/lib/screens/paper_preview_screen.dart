import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../models/paper.dart';
import '../services/pdf_service.dart';
import '../theme.dart';
import '../widgets/common.dart';

class PaperPreviewScreen extends StatefulWidget {
  final Paper paper;
  const PaperPreviewScreen({super.key, required this.paper});

  @override
  State<PaperPreviewScreen> createState() => _PaperPreviewScreenState();
}

class _PaperPreviewScreenState extends State<PaperPreviewScreen> {
  bool _busy = false;
  bool _withKey = false;

  Future<Uint8List> _bytes() =>
      PdfService.build(widget.paper, includeAnswerKey: _withKey);

  Future<void> _run(Future<void> Function(Uint8List) action, String ok) async {
    setState(() => _busy = true);
    try {
      await action(await _bytes());
      if (mounted) toast(context, ok);
    } catch (e) {
      if (mounted) {
        toast(context, 'Could not create the PDF. Please try again.',
            bad: true);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.paper;
    return Scaffold(
      backgroundColor: A.bg,
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 8),
              child: Row(
                children: [
                  BackChip(onTap: () => Navigator.pop(context)),
                  const Spacer(),
                  Text('Achievers',
                      style: A.display(17, w: FontWeight.w600, c: A.gold)),
                ],
              ),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
                children: [
                  Panel(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(p.title,
                            style: A.display(19, w: FontWeight.w600, h: 1.3)),
                        const SizedBox(height: 6),
                        Text(p.meta, style: A.body(12.5, c: A.muted)),
                        const SizedBox(height: 16),
                        Container(height: 1, color: A.line),
                        const SizedBox(height: 14),
                        Row(
                          children: [
                            _Meta('Time', p.time),
                            _Meta('Date',
                                DateFormat('dd MMM yyyy').format(p.createdAt)),
                            _Meta('Marks', '${p.marks}'),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 16),
                  ...List.generate(p.questions.length, (i) {
                    final q = p.questions[i];
                    return Panel(
                      margin: const EdgeInsets.only(bottom: 10),
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text('Q${i + 1}.',
                                  style: A.body(14,
                                      w: FontWeight.w700, c: A.gold)),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(q.text,
                                    style: A.body(14.5,
                                        w: FontWeight.w600, h: 1.45)),
                              ),
                            ],
                          ),
                          const SizedBox(height: 10),
                          ...List.generate(q.options.length, (o) {
                            final isAns = _withKey && q.answer == o;
                            return Padding(
                              padding: const EdgeInsets.only(
                                  left: 26, bottom: 5),
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width: 20,
                                    height: 20,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color:
                                          isAns ? A.teal : Colors.transparent,
                                      border: Border.all(
                                          color: isAns ? A.teal : A.muted,
                                          width: 1.4),
                                    ),
                                    alignment: Alignment.center,
                                    child: Text(
                                      const ['A', 'B', 'C', 'D'][o],
                                      style: A.body(10,
                                          w: FontWeight.w700,
                                          c: isAns ? A.bg : A.muted),
                                    ),
                                  ),
                                  const SizedBox(width: 9),
                                  Expanded(
                                    child: Text(q.options[o],
                                        style: A.body(13.5,
                                            c: isAns ? A.teal : A.muted,
                                            h: 1.4)),
                                  ),
                                ],
                              ),
                            );
                          }),
                        ],
                      ),
                    );
                  }),
                ],
              ),
            ),
            // action bar
            Container(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
              decoration: BoxDecoration(
                color: A.bg2,
                border: Border(top: BorderSide(color: A.line)),
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: GhostButton(
                          label: _withKey ? 'Hide answers' : 'Show answers',
                          icon: Icons.key_rounded,
                          onPressed: () =>
                              setState(() => _withKey = !_withKey),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: GhostButton(
                          label: 'Share',
                          icon: Icons.share_rounded,
                          onPressed: _busy
                              ? null
                              : () => _run(
                                  (b) => PdfService.share(b, p), 'Shared'),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: GhostButton(
                          label: 'Print',
                          icon: Icons.print_rounded,
                          onPressed: _busy
                              ? null
                              : () => _run(PdfService.printOut, 'Sent to print'),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  GoldButton(
                    label: 'Download as PDF',
                    icon: Icons.download_rounded,
                    loading: _busy,
                    onPressed: () => _run((b) async {
                      final f = await PdfService.save(b, p);
                      if (mounted) {
                        toast(context, 'Saved to ${f.path.split('/').last}');
                      }
                    }, 'Saved'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _Meta extends StatelessWidget {
  final String k, v;
  const _Meta(this.k, this.v);

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(k.toUpperCase(),
              style: A.body(9.5, w: FontWeight.w700, c: A.muted, ls: 1)),
          const SizedBox(height: 3),
          Text(v, style: A.body(13.5, w: FontWeight.w600)),
        ],
      ),
    );
  }
}
