import 'package:flutter/material.dart';
import '../models/question.dart';
import '../services/store.dart';
import '../theme.dart';
import '../widgets/common.dart';

/// Subject grid → question list, matching the web app, with search and delete
/// added on top.
class QuestionBankScreen extends StatefulWidget {
  const QuestionBankScreen({super.key});

  @override
  State<QuestionBankScreen> createState() => _QuestionBankScreenState();
}

class _QuestionBankScreenState extends State<QuestionBankScreen> {
  String? _subject;
  final _search = TextEditingController();

  static const _icons = {
    'Biology': '🧬',
    'Chemistry': '⚗️',
    'Physics': '🔭',
    'Maths': '📐',
  };

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: A.bg,
      body: SafeArea(
        child: ListenableBuilder(
          listenable: Store.instance,
          builder: (context, _) =>
              _subject == null ? _subjectGrid() : _questionList(),
        ),
      ),
    );
  }

  Widget _subjectGrid() {
    final store = Store.instance;
    final subjects = store.subjects;
    return ListView(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
      children: [
        BackChip(onTap: () => Navigator.pop(context)),
        const SizedBox(height: 18),
        const SectionTitle('Question Bank',
            subtitle: 'Pick a subject to explore'),
        const SizedBox(height: 22),
        if (store.questions.isEmpty)
          const EmptyState(
              emoji: '📭',
              message:
                  'Your bank is empty.\nImport an Excel or CSV file from Settings.')
        else
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 12,
            crossAxisSpacing: 12,
            childAspectRatio: 1.05,
            children: subjects.map((s) {
              final n = store.questions.where((q) => q.subject == s).length;
              return Panel(
                onTap: () => setState(() => _subject = s),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(_icons[s] ?? '📘',
                        style: const TextStyle(fontSize: 30)),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(s, style: A.display(17, w: FontWeight.w600)),
                        const SizedBox(height: 2),
                        Text('$n question${n == 1 ? '' : 's'}',
                            style: A.body(12, c: A.muted)),
                      ],
                    ),
                  ],
                ),
              );
            }).toList(),
          ),
      ],
    );
  }

  Widget _questionList() {
    final store = Store.instance;
    final term = _search.text.trim().toLowerCase();
    final list = store.questions.where((q) {
      if (q.subject != _subject) return false;
      if (term.isEmpty) return true;
      return q.text.toLowerCase().contains(term) ||
          q.topic.toLowerCase().contains(term) ||
          q.chapter.toLowerCase().contains(term);
    }).toList();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
          child: Row(
            children: [
              BackChip(onTap: () => setState(() {
                    _subject = null;
                    _search.clear();
                  })),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(_subject!, style: A.display(21, w: FontWeight.w600)),
                    Text('${list.length} shown',
                        style: A.body(12, c: A.muted)),
                  ],
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 6),
          child: TextField(
            controller: _search,
            onChanged: (_) => setState(() {}),
            style: A.body(14),
            decoration: const InputDecoration(
              hintText: 'Search question, topic or chapter',
              prefixIcon: Icon(Icons.search_rounded, color: A.muted, size: 20),
            ),
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? const EmptyState(
                  emoji: '🔍', message: 'Nothing matched that search.')
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 28),
                  itemCount: list.length,
                  itemBuilder: (_, i) => _QuestionTile(q: list[i]),
                ),
        ),
      ],
    );
  }
}

class _QuestionTile extends StatelessWidget {
  final Question q;
  const _QuestionTile({required this.q});

  @override
  Widget build(BuildContext context) {
    return Panel(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(15),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Text(q.text,
                    style: A.body(14, w: FontWeight.w600, h: 1.45)),
              ),
              InkWell(
                onTap: () async {
                  final ok = await showDialog<bool>(
                    context: context,
                    builder: (_) => AlertDialog(
                      backgroundColor: A.panelHi,
                      title: Text('Delete this question?',
                          style: A.display(17, w: FontWeight.w600)),
                      content: Text(q.text, style: A.body(13.5, c: A.muted)),
                      actions: [
                        TextButton(
                            onPressed: () => Navigator.pop(context, false),
                            child: Text('Cancel',
                                style: A.body(14, c: A.muted))),
                        TextButton(
                            onPressed: () => Navigator.pop(context, true),
                            child: Text('Delete',
                                style: A.body(14,
                                    c: const Color(0xFFFCA5A5),
                                    w: FontWeight.w600))),
                      ],
                    ),
                  );
                  if (ok == true) await Store.instance.deleteQuestion(q.id);
                },
                child: const Padding(
                  padding: EdgeInsets.only(left: 8),
                  child: Icon(Icons.close_rounded, size: 18, color: A.muted),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          ...List.generate(q.options.length, (o) {
            final ok = q.answer == o;
            return Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 18,
                    height: 18,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: ok ? A.teal : Colors.transparent,
                      border: Border.all(
                          color: ok ? A.teal : A.muted, width: 1.3),
                    ),
                    alignment: Alignment.center,
                    child: Text(const ['A', 'B', 'C', 'D'][o],
                        style: A.body(9,
                            w: FontWeight.w700, c: ok ? A.bg : A.muted)),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(q.options[o],
                        style: A.body(13,
                            c: ok ? A.teal : A.muted,
                            w: ok ? FontWeight.w600 : FontWeight.w400)),
                  ),
                ],
              ),
            );
          }),
          const SizedBox(height: 10),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              if (q.chapter.isNotEmpty) _Tag(q.chapter),
              if (q.topic.isNotEmpty) _Tag(q.topic),
              _Tag(q.difficulty, gold: true),
              if (q.standard.isNotEmpty) _Tag(q.standard),
            ],
          ),
        ],
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  final String text;
  final bool gold;
  const _Tag(this.text, {this.gold = false});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
      decoration: BoxDecoration(
        color: (gold ? A.gold : A.teal).withOpacity(.12),
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(text,
          style: A.body(10.5,
              w: FontWeight.w600, c: gold ? A.gold : A.teal)),
    );
  }
}
