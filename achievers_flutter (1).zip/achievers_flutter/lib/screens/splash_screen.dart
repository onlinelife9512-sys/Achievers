import 'dart:math' as math;
import 'package:flutter/material.dart';
import '../theme.dart';
import 'menu_screen.dart';

/// Recreates the web app's opening screen: radiating gold rays behind the
/// wordmark, with "Tap anywhere to begin".
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {
  late final AnimationController _spin =
      AnimationController(vsync: this, duration: const Duration(seconds: 46))
        ..repeat();
  late final AnimationController _intro =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1100))
        ..forward();
  late final AnimationController _pulse =
      AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))
        ..repeat(reverse: true);

  @override
  void dispose() {
    _spin.dispose();
    _intro.dispose();
    _pulse.dispose();
    super.dispose();
  }

  void _enter() {
    Navigator.of(context).pushReplacement(PageRouteBuilder(
      transitionDuration: const Duration(milliseconds: 480),
      pageBuilder: (_, a, __) => FadeTransition(
        opacity: a,
        child: const MenuScreen(),
      ),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final fade = CurvedAnimation(parent: _intro, curve: Curves.easeOut);
    return Scaffold(
      backgroundColor: A.bg,
      body: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _enter,
        child: Stack(
          alignment: Alignment.center,
          children: [
            // rotating rays
            AnimatedBuilder(
              animation: _spin,
              builder: (_, __) => Transform.rotate(
                angle: _spin.value * 2 * math.pi,
                child: CustomPaint(
                  size: const Size(double.infinity, double.infinity),
                  painter: _RayPainter(),
                ),
              ),
            ),
            // soft glow behind the wordmark
            Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: RadialGradient(colors: [
                  A.gold.withOpacity(.16),
                  A.gold.withOpacity(0),
                ]),
              ),
            ),
            FadeTransition(
              opacity: fade,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  ShaderMask(
                    shaderCallback: (r) => const LinearGradient(
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                      colors: [Colors.white, A.goldLt],
                    ).createShader(r),
                    child: Text('Achievers',
                        style: A.display(46,
                            w: FontWeight.w600, c: Colors.white)),
                  ),
                  const SizedBox(height: 10),
                  Text('Generate Papers in Seconds',
                      style: A.body(14, c: A.muted, ls: .3)),
                  const SizedBox(height: 46),
                  FadeTransition(
                    opacity: Tween(begin: .35, end: 1.0).animate(_pulse),
                    child: Text('Tap anywhere to begin',
                        style: A.body(12.5, c: A.gold, ls: 1.4)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RayPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final r = size.longestSide * .75;
    const count = 14;
    for (var i = 0; i < count; i++) {
      final a = (i / count) * 2 * math.pi;
      final paint = Paint()
        ..shader = LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [A.goldLt.withOpacity(.17), A.goldLt.withOpacity(0)],
        ).createShader(Rect.fromLTWH(0, 0, 30, r));
      canvas.save();
      canvas.translate(c.dx, c.dy);
      canvas.rotate(a);
      final path = Path()
        ..moveTo(-13, 0)
        ..lineTo(13, 0)
        ..lineTo(2, -r)
        ..lineTo(-2, -r)
        ..close();
      canvas.drawPath(path, paint);
      canvas.restore();
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}
