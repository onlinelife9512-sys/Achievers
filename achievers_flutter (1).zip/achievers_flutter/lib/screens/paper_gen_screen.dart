import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../models/paper.dart';
import '../models/question.dart';
import '../services/store.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'paper_preview_screen.dart';

class PaperGenScreen extends StatefulWidget {
  const PaperGenScreen({super.key});

  @override
  State<PaperGenScreen> createState() => _PaperGenScreenState();
}

class _PaperGenScreenState extends State<PaperGenScreen> {
  final _store = Store.instance;
  final _count = TextEditingController(text: '10');
  final _marks = TextEditingController();
  final _time = TextEditingController(text: '1 Hour');

  String _subject = 'Biology';
  String _standard = 'Class 11';
  String? _chapter;
  final Set<String> _topics = {};
  String _difficulty = 'All';

  static const _difficulties = ['All', 'Easy', 'Medium', 'Hard'];

  @override
  void initState() {
    super.initState();
    final subs = _store.subjects;
    _subject = subs.contains('Biology') ? 'Biology' : subs.first;
    _syncChapter();
  }

  @override
  void dispose() {
    _count.dispose();
    _marks.dispose();
    _time.dispose();
    super.dispose();
  }

  String get _std => _standard.contains('11') ? '11th' : '12th';

  Map<String, List<String>> get _chapters => _store.chapterMap(_subject);

  void _syncChapter() {
    final keys = _chapters.keys.toList()..sort();
    if (_chapter == null || !keys.contains(_chapter)) {
      _chapter = keys.isEmpty ? null : keys.first;
    }
    _topics.removeWhere((t) => !(_chapters[_chapter] ?? const []).contains(t));
  }

  List<Question> get _pool => _store.pool(
        subject: _subject,
        standard: _std,
        chapter: _chapter,
        difficulty: _difficulty,
        topics: _topics,
      );

  Future<void> _generate() async {
    final pool = _pool;
    if (pool.isEmpty) {
      toast(context,
          'No questions match this combination — try another chapter, topic or difficulty.',
          bad: true);
      return;
    }
    var count = int.tryParse(_count.text) ?? 5;
    count = count.clamp(1, pool.length);

    final picked = ([...pool]..shuffle(Random())).take(count).toList();
    final marks = int.tryParse(_marks.text) ?? count * 4;

    final paper = Paper(
      id: 'p_${DateTime.now().microsecondsSinceEpoch}',
      title: '$_subject — $_standard — ${_chapter ?? 'All chapters'}',
      subject: _subject,
      standard: _standard,
      chapter: _chapter ?? '',
      difficulty: _difficulty == 'All' ? 'Mixed' : _difficulty,
      time: _time.text.trim().isEmpty ? '1 Hour' : _time.text.trim(),
      marks: marks,
      createdAt: DateTime.now(),
      questions: picked,
    );

    await _store.addPaper(paper);
    if (!mounted) return;
    Navigator.push(context,
        MaterialPageRoute(builder: (_) => PaperPreviewScreen(paper: paper)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: A.bg,
      body: SafeArea(
        child: ListenableBuilder(
          listenable: _store,
          builder: (context, _) {
            _syncChapter();
            final chapters = _chapters.keys.toList()..sort();
            final topics = _chapters[_chapter] ?? const <String>[];
            final available = _pool.length;

            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 40),
              children: [
                BackChip(onTap: () => Navigator.pop(context)),
                const SizedBox(height: 18),
                const SectionTitle('Paper Generation',
                    subtitle: 'Create a fresh question paper'),
                const SizedBox(height: 22),

                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      LabeledDropdown(
                        label: 'Subject',
                        value: _subject,
                        items: _store.subjects,
                        onChanged: (v) => setState(() {
                          _subject = v!;
                          _chapter = null;
                          _topics.clear();
                          _syncChapter();
                        }),
                      ),
                      const SizedBox(height: 16),
                      LabeledDropdown(
                        label: 'Class / Standard',
                        value: _standard,
                        items: const ['Class 11', 'Class 12'],
                        onChanged: (v) => setState(() => _standard = v!),
                      ),
                      const SizedBox(height: 16),
                      LabeledDropdown(
                        label: 'Chapter',
                        value: _chapter,
                        items: chapters,
                        hint: 'No chapters yet',
                        onChanged: (v) => setState(() {
                          _chapter = v;
                          _topics.clear();
                        }),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('TOPICS',
                          style: A.body(10.5,
                              w: FontWeight.w700, c: A.muted, ls: 1.1)),
                      const SizedBox(height: 5),
                      Text(
                        _topics.isEmpty
                            ? 'None selected — the whole chapter is used'
                            : '${_topics.length} selected',
                        style: A.body(12, c: A.muted),
                      ),
                      const SizedBox(height: 12),
                      if (topics.isEmpty)
                        Text('No topics in this chapter.',
                            style: A.body(13, c: A.muted))
                      else
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: topics
                              .map((t) => Chip2(
                                    label: t,
                                    active: _topics.contains(t),
                                    onTap: () => setState(() {
                                      _topics.contains(t)
                                          ? _topics.remove(t)
                                          : _topics.add(t);
                                    }),
                                  ))
                              .toList(),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                Panel(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('DIFFICULTY',
                          style: A.body(10.5,
                              w: FontWeight.w700, c: A.muted, ls: 1.1)),
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _difficulties
                            .map((d) => Chip2(
                                  label: d,
                                  active: _difficulty == d,
                                  onTap: () =>
                                      setState(() => _difficulty = d),
                                ))
                            .toList(),
                      ),
                      const SizedBox(height: 16),
                      Row(
                        children: [
                          Expanded(
                            child: _NumField(
                              label: 'Number of Questions',
                              controller: _count,
                              hint: '10',
                              onChanged: (_) => setState(() {}),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: _NumField(
                              label: 'Total Marks',
                              controller: _marks,
                              hint: 'auto',
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 14),
                      Text('TIME ALLOWED',
                          style: A.body(10.5,
                              w: FontWeight.w700, c: A.muted, ls: 1.1)),
                      const SizedBox(height: 7),
                      TextField(
                        controller: _time,
                        decoration:
                            const InputDecoration(hintText: '1 Hour'),
                        style: A.body(14.5, w: FontWeight.w500),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 14),

                // Live count — the web app silently produced an alert only
                // after you pressed Generate.
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 13),
                  decoration: BoxDecoration(
                    color: available == 0
                        ? const Color(0x337F1D1D)
                        : A.teal.withOpacity(.10),
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(
                        color: available == 0
                            ? const Color(0x557F1D1D)
                            : A.teal.withOpacity(.25)),
                  ),
                  child: Row(
                    children: [
                      Icon(
                          available == 0
                              ? Icons.error_outline_rounded
                              : Icons.check_circle_outline_rounded,
                          size: 18,
                          color: available == 0
                              ? const Color(0xFFFCA5A5)
                              : A.teal),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          available == 0
                              ? 'No questions match this combination'
                              : '$available question${available == 1 ? '' : 's'} available',
                          style: A.body(13,
                              w: FontWeight.w600,
                              c: available == 0
                                  ? const Color(0xFFFCA5A5)
                                  : A.teal),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                GoldButton(
                  label: 'Generate Paper  ✨',
                  onPressed: available == 0 ? null : _generate,
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _NumField extends StatelessWidget {
  final String label, hint;
  final TextEditingController controller;
  final ValueChanged<String>? onChanged;

  const _NumField({
    required this.label,
    required this.controller,
    required this.hint,
    this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label.toUpperCase(),
            style: A.body(10.5, w: FontWeight.w700, c: A.muted, ls: 1.1)),
        const SizedBox(height: 7),
        TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            LengthLimitingTextInputFormatter(4),
          ],
          decoration: InputDecoration(hintText: hint),
          style: A.body(14.5, w: FontWeight.w500),
          onChanged: onChanged,
        ),
      ],
    );
  }
}
