import 'package:flutter/material.dart';
import '../theme.dart';

/// Panel card — the web app's linear-gradient(155deg, panel, bg2) surface.
class Panel extends StatelessWidget {
  final Widget child;
  final EdgeInsetsGeometry padding;
  final EdgeInsetsGeometry? margin;
  final double radius;
  final VoidCallback? onTap;
  final Border? border;

  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.margin,
    this.radius = 20,
    this.onTap,
    this.border,
  });

  @override
  Widget build(BuildContext context) {
    final body = Container(
      padding: padding,
      decoration: BoxDecoration(
        gradient: A.panelGrad,
        borderRadius: BorderRadius.circular(radius),
        border: border ?? Border.all(color: A.line),
        boxShadow: const [
          BoxShadow(color: Color(0x33000000), blurRadius: 18, offset: Offset(0, 8)),
        ],
      ),
      child: child,
    );
    if (onTap == null) return Container(margin: margin, child: body);
    return Container(
      margin: margin,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(radius),
          child: body,
        ),
      ),
    );
  }
}

/// Gold gradient call-to-action, with a press-scale like the web app.
class GoldButton extends StatefulWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final bool loading;
  final bool expand;

  const GoldButton({
    super.key,
    required this.label,
    this.icon,
    this.onPressed,
    this.loading = false,
    this.expand = true,
  });

  @override
  State<GoldButton> createState() => _GoldButtonState();
}

class _GoldButtonState extends State<GoldButton> {
  double _s = 1;

  @override
  Widget build(BuildContext context) {
    final enabled = widget.onPressed != null && !widget.loading;
    return GestureDetector(
      onTapDown: enabled ? (_) => setState(() => _s = .97) : null,
      onTapUp: enabled ? (_) => setState(() => _s = 1) : null,
      onTapCancel: enabled ? () => setState(() => _s = 1) : null,
      onTap: enabled ? widget.onPressed : null,
      child: AnimatedScale(
        scale: _s,
        duration: const Duration(milliseconds: 120),
        child: Opacity(
          opacity: enabled ? 1 : .5,
          child: Container(
            width: widget.expand ? double.infinity : null,
            padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 17),
            decoration: BoxDecoration(
              gradient: A.goldGrad,
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: A.gold.withOpacity(.28),
                  blurRadius: 20,
                  offset: const Offset(0, 8),
                ),
              ],
            ),
            child: widget.loading
                ? const SizedBox(
                    height: 20,
                    width: 20,
                    child: CircularProgressIndicator(
                        strokeWidth: 2.4, color: Color(0xFF0A1120)),
                  )
                : Row(
                    mainAxisSize: MainAxisSize.min,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (widget.icon != null) ...[
                        Icon(widget.icon, size: 19, color: A.bg),
                        const SizedBox(width: 9),
                      ],
                      Flexible(
                        child: Text(
                          widget.label,
                          textAlign: TextAlign.center,
                          style: A.body(15.5,
                              w: FontWeight.w700, c: A.bg, ls: .1),
                        ),
                      ),
                    ],
                  ),
          ),
        ),
      ),
    );
  }
}

/// Outlined secondary button.
class GhostButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onPressed;
  final Color? color;

  const GhostButton(
      {super.key,
      required this.label,
      this.icon,
      this.onPressed,
      this.color});

  @override
  Widget build(BuildContext context) {
    final c = color ?? A.text;
    return Material(
      color: A.panelHi,
      borderRadius: BorderRadius.circular(14),
      child: InkWell(
        onTap: onPressed,
        borderRadius: BorderRadius.circular(14),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: A.line),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              if (icon != null) ...[
                Icon(icon, size: 17, color: c),
                const SizedBox(width: 8),
              ],
              Flexible(
                child: Text(label,
                    textAlign: TextAlign.center,
                    style: A.body(13.5, w: FontWeight.w600, c: c)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Selectable pill — the web app's .chip.
class Chip2 extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;

  const Chip2(
      {super.key,
      required this.label,
      required this.active,
      required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 10),
        decoration: BoxDecoration(
          gradient: active ? A.goldGrad : null,
          color: active ? null : A.panelHi,
          borderRadius: BorderRadius.circular(22),
          border: Border.all(color: active ? Colors.transparent : A.line),
        ),
        child: Text(
          label,
          style: A.body(13,
              w: active ? FontWeight.w700 : FontWeight.w500,
              c: active ? A.bg : A.text),
        ),
      ),
    );
  }
}

/// Label + dropdown pair used throughout the generator form.
class LabeledDropdown extends StatelessWidget {
  final String label;
  final String? value;
  final List<String> items;
  final ValueChanged<String?> onChanged;
  final String? hint;

  const LabeledDropdown({
    super.key,
    required this.label,
    required this.value,
    required this.items,
    required this.onChanged,
    this.hint,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label.toUpperCase(),
            style: A.body(10.5, w: FontWeight.w700, c: A.muted, ls: 1.1)),
        const SizedBox(height: 7),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 14),
          decoration: BoxDecoration(
            color: A.panelHi,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: A.line),
          ),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: items.contains(value) ? value : null,
              isExpanded: true,
              hint: Text(hint ?? 'Select', style: A.body(14, c: A.muted)),
              dropdownColor: A.panelHi,
              borderRadius: BorderRadius.circular(14),
              icon: const Icon(Icons.keyboard_arrow_down_rounded,
                  color: A.muted),
              style: A.body(14.5, w: FontWeight.w500),
              padding: const EdgeInsets.symmetric(vertical: 4),
              items: items
                  .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                  .toList(),
              onChanged: onChanged,
            ),
          ),
        ),
      ],
    );
  }
}

class SectionTitle extends StatelessWidget {
  final String title;
  final String? subtitle;
  const SectionTitle(this.title, {super.key, this.subtitle});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: A.display(28, w: FontWeight.w600)),
        if (subtitle != null) ...[
          const SizedBox(height: 4),
          Text(subtitle!, style: A.body(13.5, c: A.muted)),
        ],
      ],
    );
  }
}

class EmptyState extends StatelessWidget {
  final String emoji;
  final String message;
  const EmptyState({super.key, required this.emoji, required this.message});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 54, horizontal: 24),
      child: Column(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 42)),
          const SizedBox(height: 14),
          Text(message,
              textAlign: TextAlign.center,
              style: A.body(14, c: A.muted, h: 1.6)),
        ],
      ),
    );
  }
}

/// Back chevron used at the top of every inner screen.
class BackChip extends StatelessWidget {
  final VoidCallback onTap;
  const BackChip({super.key, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: A.panelHi,
      shape: const CircleBorder(),
      child: InkWell(
        customBorder: const CircleBorder(),
        onTap: onTap,
        child: Container(
          width: 42,
          height: 42,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            border: Border.all(color: A.line),
          ),
          child: const Icon(Icons.arrow_back_rounded, size: 19, color: A.text),
        ),
      ),
    );
  }
}

void toast(BuildContext context, String msg, {bool bad = false}) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: bad ? const Color(0xFF7F1D1D) : A.panelHi,
    ));
}
