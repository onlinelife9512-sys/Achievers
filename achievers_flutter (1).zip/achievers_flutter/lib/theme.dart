import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Tokens lifted straight from the web app's :root block so the Flutter build
/// looks identical to vijaysirpatel.netlify.app.
class A {
  static const bg = Color(0xFF0A1120);
  static const bg2 = Color(0xFF0F1A2E);
  static const panel = Color(0xFF131F36);
  static const panelHi = Color(0xFF182543);
  static const gold = Color(0xFFF0B429);
  static const goldLt = Color(0xFFFFD874);
  static const teal = Color(0xFF2DD9C4);
  static const violet = Color(0xFF8A6CF0);
  static const text = Color(0xFFF4F1EA);
  static const muted = Color(0xFF8A93A6);
  static const line = Color(0x14F4F1EA); // rgba(244,241,234,0.08)

  static const goldGrad = LinearGradient(
    colors: [goldLt, gold],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const tealGrad = LinearGradient(
    colors: [Color(0xFF6BF0E0), teal],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const violetGrad = LinearGradient(
    colors: [Color(0xFFB9A6FF), violet],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );
  static const panelGrad = LinearGradient(
    colors: [panel, bg2],
    begin: Alignment(-0.6, -1),
    end: Alignment(0.6, 1),
  );

  // Fraunces for headings, Inter for everything else — same as the web app.
  static TextStyle display(double size,
          {FontWeight w = FontWeight.w600, Color? c, double? h}) =>
      GoogleFonts.fraunces(
          fontSize: size, fontWeight: w, color: c ?? text, height: h);

  static TextStyle body(double size,
          {FontWeight w = FontWeight.w400, Color? c, double? h, double? ls}) =>
      GoogleFonts.inter(
          fontSize: size,
          fontWeight: w,
          color: c ?? text,
          height: h,
          letterSpacing: ls);

  static ThemeData theme() {
    final base = ThemeData(brightness: Brightness.dark, useMaterial3: true);
    return base.copyWith(
      scaffoldBackgroundColor: bg,
      colorScheme: base.colorScheme.copyWith(
        primary: gold,
        secondary: teal,
        surface: panel,
      ),
      textTheme: GoogleFonts.interTextTheme(base.textTheme)
          .apply(bodyColor: text, displayColor: text),
      splashColor: gold.withOpacity(0.08),
      highlightColor: Colors.transparent,
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: panelHi,
        hintStyle: body(14, c: muted),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: line),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: line),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: gold, width: 1.4),
        ),
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: panelHi,
        contentTextStyle: body(13.5, c: text),
        behavior: SnackBarBehavior.floating,
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    );
  }
}
